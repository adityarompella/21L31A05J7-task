import React, { useState } from 'react';
import productsFetchHook from '../hooks/productsFetchHook'
function HomeScreen() {
    const companies = ["AMZ", "FLP", "SNP", "MYN", "AZO"];
    const categories = ["Phone", "Compani", "TV", "Earphone", "Tablet", "Charger", "Mouse",
        "Keyboard", "Bluetooth", "Pendrive", "Remote", "Speaker", "Headset", "Laptop", "PC"
    ];

    const [selectedCompany, setSelectedCompany] = useState("AMZ");
    const [selectedCategory, setSelectedCategory] = useState("Phone");
    const [top, setTop] = useState(10); // Number of products to fetch
    const [minPrice, setMinPrice] = useState(1);
    const [maxPrice, setMaxPrice] = useState(10000);

    const { data, loading, error } = productsFetchHook(selectedCompany, selectedCategory, top, minPrice, maxPrice);

    return (
        <div>
            <div>
                <label htmlFor="company">Company:</label>
                <select
                    id="company"
                    value={selectedCompany}
                    onChange={(e) => setSelectedCompany(e.target.value)}
                >
                    {companies.map((company) => (
                        <option key={company} value={company}>
                            {company}
                        </option>
                    ))}
                </select>
            </div>

            <div>
                <label htmlFor="category">Category:</label>
                <select
                    id="category"
                    value={selectedCategory}
                    onChange={(e) => setSelectedCategory(e.target.value)}
                >
                    {categories.map((category) => (
                        <option key={category} value={category}>
                            {category}
                        </option>
                    ))}
                </select>
            </div>

            <div>
                <label htmlFor="top">Number of Products:</label>
                <input
                    id="top"
                    type="number"
                    value={top}
                    min="1"
                    onChange={(e) => setTop(e.target.value)}
                />
            </div>

            <div>
                <label htmlFor="minPrice">Min Price:</label>
                <input
                    id="minPrice"
                    type="number"
                    value={minPrice}
                    min="1"
                    onChange={(e) => setMinPrice(e.target.value)}
                />
            </div>

            <div>
                <label htmlFor="maxPrice">Max Price:</label>
                <input
                    id="maxPrice"
                    type="number"
                    value={maxPrice}
                    min="1"
                    max="10000"
                    onChange={(e) => setMaxPrice(e.target.value)}
                />
            </div>

            {loading && <p>Loading...</p>}
            {error && <p>Error: {error}</p>}
            {data.length > 0 && (
                <table>
                    <thead>
                        <tr>
                            <th>Product Name</th>
                            <th>Price</th>
                            <th>Rating</th>
                            <th>Discount</th>
                            <th>Availability</th>
                        </tr>
                    </thead>
                    <tbody>
                        {data.map((product, index) => (
                            <tr key={index}>
                                <td>{product.productName}</td>
                                <td>{product.price}</td>
                                <td>{product.rating}</td>
                                <td>{product.discount}%</td>
                                <td>{product.availability}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            )}
        </div>
    );
}

export default HomeScreen;
